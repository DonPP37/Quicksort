package quicksort;

import java.util.Random;

public class GenerarArray {
   static int [] generarArray(int elementos){
       Random r = new Random();
       int[] array = new int[elementos];
       for (int i = 0; i < array.length; i++) {
           array [i] = r.nextInt(elementos);
       }
       return array;
   }
   
}