
package quicksort;

import java.util.Arrays;

 class Main {


    public static void main(String[] args) {
        System.out.print("\nlista sin ordenar: ");
        int [] array1  = GenerarArray.generarArray(10);
        System.out.println(Arrays.toString(array1));
        
       Quicksort.quicksort(array1, 0, array1.length-1);
        System.out.println("\nLista ordenada: ");
        System.out.println(Arrays.toString(array1));
    }
    
}
